/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectobanco_dominio;

/**
 *
 * @author Jesus Gabriel
 */
public class ProyectoBanco_Dominio {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
