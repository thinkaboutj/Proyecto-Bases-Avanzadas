/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectobanco_interfaz;

/**
 *
 * @author Jesus Gabriel
 */
public class ProyectoBanco_interfaz {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
